import { Injectable } from '@angular/core';

import {HttpClient} from "@angular/common/http";
import { Respuesta } from '../entidades/respuesta';
import { Proyecto } from '../entidades/proyecto';
import { Espacios } from '../entidades/espacios';

@Injectable({
  providedIn: 'root'
})
export class OperacionesService {

  rutaservicio: string = 'http://localhost:8080/ServAuten/app/consulta/consultaproy';

  rutaservicios: string = 'http://localhost:8080/ServAuten/app/consulta/consultaespacio';

  
  constructor(private http: HttpClient) { }
  
  consultar():Promise<Proyecto[]>{
    return this.http.get<Proyecto[]>(`${this.rutaservicio}`).toPromise();

  }

  consultaresp():Promise<Espacios[]>{
    return this.http.get<Espacios[]>(`${this.rutaservicios}`).toPromise();

  }
 




}
