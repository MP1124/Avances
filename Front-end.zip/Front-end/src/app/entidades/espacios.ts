export interface Espacios {
    idespacio: number;
    nombre:String;
    ubicacion_lugar:String;
    Capacidad:String;
    nivel_practica:String;
}
