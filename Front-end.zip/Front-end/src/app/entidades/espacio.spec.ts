import { Espacio } from './espacio';

describe('Espacio', () => {
  it('should create an instance', () => {
    expect(new Espacio()).toBeTruthy();
  });
});
