export interface Proyecto {
    idproyecto: number;
    nombre_evaluador:String;
    nombre_estudiante:String;
    nombre_proyecto:String;
}
