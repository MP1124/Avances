export interface Respuesta {
    idproyecto: number;
    nombre_evaluador:String;
    nombre_estudiante:String;
    nombre_proyecto:String;
}
