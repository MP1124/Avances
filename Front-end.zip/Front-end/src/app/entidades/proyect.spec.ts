import { Proyect } from './proyect';

describe('Proyect', () => {
  it('should create an instance', () => {
    expect(new Proyect()).toBeTruthy();
  });
});
