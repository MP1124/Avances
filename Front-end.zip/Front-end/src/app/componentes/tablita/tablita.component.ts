import { Component, OnInit, ViewChild } from '@angular/core';
import { Espacios } from 'src/app/entidades/espacios';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { OperacionesService } from 'src/app/servicios/operaciones.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';


@Component({
  selector: 'app-tablita',
  templateUrl: './tablita.component.html',
  styleUrls: ['./tablita.component.css']
})
export class TablitaComponent implements OnInit {
  espacio: Espacios[] = [{idespacio:123,nombre:"prueba1",Capacidad:"15",nivel_practica:"1",ubicacion_lugar:"torrep"}];
  displayedColumns: string[];
  dataSource: MatTableDataSource<Espacios>;

  selection: SelectionModel<Espacios>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
 

  cargarTabla() {
    const x: Promise<Espacios[]> = this.servicio.consultaresp();
    x.then((value: Espacios[]) => {
      if (value === undefined) {
        const espacio: Espacios[] = [{ idespacio:123,nombre:"prueba1",Capacidad:"15",nivel_practica:"1",ubicacion_lugar:"torrep" },{ idespacio:13,nombre:"prueba2",Capacidad:"5",nivel_practica:"5",ubicacion_lugar:"torrep" },]
        this.espacio = espacio;
        this.displayedColumns = ['idespacio', 'nombre','ubicacion_lugar', 'Capacidad','nivel_practica'];
        this.dataSource = new MatTableDataSource<Espacios>(this.espacio);
        this.selection = new SelectionModel<Espacios>(false, []);
        this.dataSource.sort = this.sort;
      }
      else {
        this.espacio = value;
        // this.displayedColumns = ['select', 'idproyecto', 'nombre_estudiante', 'nombre_evaluador'];
        this.displayedColumns = ['idespacio', 'nombre','ubicacion_lugar', 'Capacidad','nivel_practica'];
        this.dataSource = new MatTableDataSource<Espacios>(this.espacio);
        this.selection = new SelectionModel<Espacios>(false, []);
        this.dataSource.sort = this.sort;
        
      }
    });
  }

  constructor(private servicio:OperacionesService) { 
    this.cargarTabla();
  }

  ngOnInit(): void {
  }
}
  export interface PeriodicElement {
    name: string;
    position: number;
    weight: number;
    symbol: string;
  }
  
  const ELEMENT_DATA: PeriodicElement[] = [
    {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
    {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
    {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
    {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
    {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
    {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
    {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
    {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
    {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
    {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
  ];
  

