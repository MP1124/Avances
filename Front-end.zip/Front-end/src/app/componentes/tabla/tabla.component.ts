import { Component, OnInit, ViewChild } from '@angular/core';
import { Proyecto } from 'src/app/entidades/proyecto';
import { OperacionesService } from 'src/app/servicios/operaciones.service';
import { MatTableDataSource } from '@angular/material/table';
import { Proyect } from 'src/app/entidades/proyect';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})

export class TablaComponent implements OnInit {
  
  proyecto: Proyecto[] = [{idproyecto:123,nombre_proyecto:"prueba1",nombre_estudiante:"paula",nombre_evaluador:"pedro"}];
  displayedColumns: string[];
  dataSource: MatTableDataSource<Proyecto>;

  selection: SelectionModel<Proyecto>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;



  /** Whether the number of selected elements matches the total number of rows. */
  // isAllSelected() {
  //   const numSelected = this.selection.selected.length;
  //   const numRows = this.dataSource.data.length;
  //   return numSelected === numRows;
  // }

  // /** Selects all rows if they are not all selected; otherwise clear selection. */
  // masterToggle() {
  //   this.isAllSelected() ?
  //     this.selection.clear() :
  //     this.dataSource.data.forEach(row => this.selection.select(row));
  // }

  // /** The label for the checkbox on the passed row */

  // checkboxLabel(row?: Proyecto): string {
  //   if (!row) {
  //     return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
  //   }
  //   return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.idproyecto + 1}`;
  // }


  cargarTabla() {
    const x: Promise<Proyecto[]> = this.servicio.consultar();
    x.then((value: Proyecto[]) => {
      if (value === undefined) {
        const proyect: Proyecto[] = [{ idproyecto: 12,nombre_proyecto:"prueba1", nombre_estudiante: 'pedro',nombre_evaluador:'gustavo' },{ idproyecto: 15, nombre_proyecto:"prueba1",nombre_estudiante: 'Felipe',nombre_evaluador:'Andres' },]
        this.proyecto = proyect;
        this.displayedColumns = ['idproyecto', 'nombre_proyecto','nombre_estudiante', 'nombre_evaluador'];
        this.dataSource = new MatTableDataSource<Proyecto>(this.proyecto);
        this.selection = new SelectionModel<Proyecto>(false, []);
        this.dataSource.sort = this.sort;
      }
      else {
        this.proyecto = value;
        // this.displayedColumns = ['select', 'idproyecto', 'nombre_estudiante', 'nombre_evaluador'];
        this.displayedColumns = ['idproyecto', 'nombre_proyecto','nombre_estudiante', 'nombre_evaluador'];
        this.dataSource = new MatTableDataSource<Proyecto>(this.proyecto);
        this.selection = new SelectionModel<Proyecto>(false, []);
        this.dataSource.sort = this.sort;
        
      }
    });
  }

  constructor(private servicio:OperacionesService) {

    this.cargarTabla();

   }

  ngOnInit(): void {
  }

}
export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
];
