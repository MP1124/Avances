import { Component } from '@angular/core';
import { OperacionesService } from './servicios/operaciones.service';
import { Respuesta } from './entidades/respuesta';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'appangular';

 }

