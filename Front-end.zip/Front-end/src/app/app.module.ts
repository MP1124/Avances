import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AutenticacionComponent } from './componentes/autenticacion/autenticacion.component';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {TablaComponent} from './componentes/tabla/tabla.component';
import {MatTableModule} from '@angular/material/table';
import { Routes, RouterModule } from '@angular/router';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatPseudoCheckboxModule, MatPseudoCheckbox } from '@angular/material/core';
import {MatCheckboxModule}from '@angular/material/checkbox';
import {MatFormFieldModule}from '@angular/material/form-field';
import {MatRadioModule}from '@angular/material/radio';
import {MatSortModule}from '@angular/material/sort';
import {MatSelectModule}from '@angular/material/select';
import { OperacionesService } from './servicios/operaciones.service';
import { TablitaComponent } from './componentes/tablita/tablita.component';

const appRoutes : Routes = [
  {path: '', component : TablaComponent},
  {path: 'Proyectos', component : TablaComponent},
  {path: 'EspaciosFisicos', component : TablitaComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AutenticacionComponent,
    TablaComponent,
    TablitaComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(appRoutes),
    MatTableModule,
    MatPaginatorModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatSortModule,
    MatSelectModule
  ],
  exports: [MatTableModule,MatPaginatorModule,MatCheckboxModule,MatFormFieldModule,MatSortModule,MatSelectModule],
  providers: [OperacionesService],
  bootstrap: [AppComponent]
})


export class AppModule { }
