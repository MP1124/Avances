package co.vinni.dao;

import co.vinni.dao.Conexion;
import co.vinni.dto.Proyecto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Operacion {

    public void consultaproy(int idproyecto) throws SQLException {
        //Conexion c = new Conexion();
        PreparedStatement ps = null;
        Connection conex = Conexion.conectarse();
        if (conex == null) {
        } else {
            try {
                ps = conex.prepareStatement("select * from public.proyectos");
                ps.setInt(1, idproyecto);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    System.out.println("id proyecto: " + rs.getInt(idproyecto));
                }
                ps.close();
                conex.close();
            } catch (SQLException e) {
                System.out.println(e);
            } finally {
                if (conex != null) {
                    conex.close();
                }
                if (ps != null) {
                    ps.close();

                }   

            }
        }
    }
    public void consultaespacio(int idespacio) throws SQLException {
        //Conexion c = new Conexion();
        PreparedStatement ps = null;
        Connection conex = Conexion.conectarse();
        if (conex == null) {
        } else {
            try {
                ps = conex.prepareStatement("select * from public.espaciofisico");
                ps.setInt(1, idespacio);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    System.out.println("id espacio: " + rs.getInt(idespacio));
                }
                ps.close();
                conex.close();
            } catch (SQLException e) {
                System.out.println(e);
            } finally {
                if (conex != null) {
                    conex.close();
                }
                if (ps != null) {
                    ps.close();

                }   

            }
        }
    }
}
