package co.vinni.dao;
import java.sql.Connection;
import java.sql.DriverManager;



public class Conexion {
    public static Connection conectarse() {
        String bd = "demo"; 
        String usuario = "demo"; 
        String clave = "demo"; 
        try { 
            Class.forName("org.postgresql.Driver");
            Connection conexion = DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/"+bd,
                    usuario, clave);
            return conexion;
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al registrar el driver de PostgreSQL: " + ex);
        } catch (Exception e)
                {
                    e.printStackTrace();
                }
        return null;
    }
    
}