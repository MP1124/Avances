/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.vinni.dto;

/**
 *
 * @author Maria Paula
 */
public class Proyecto {
    private String nombre_proyecto;
    private String nombre_estudiante;
    private String nombre_evaluador;
    private int idproyecto;

    public Proyecto() {
    }

    public Proyecto(String nombre_proyecto, String nombre_estudiante, String nombre_evaluador, int idproyecto) {
        this.nombre_proyecto = nombre_proyecto;
        this.nombre_estudiante = nombre_estudiante;
        this.nombre_evaluador = nombre_evaluador;
        this.idproyecto = idproyecto;
    }

    public String getNombre_proyecto() {
        return nombre_proyecto;
    }

    public void setNombre_proyecto(String nombre_proyecto) {
        this.nombre_proyecto = nombre_proyecto;
    }

    public String getNombre_estudiante() {
        return nombre_estudiante;
    }

    public void setNombre_estudiante(String nombre_estudiante) {
        this.nombre_estudiante = nombre_estudiante;
    }

    public String getNombre_evaluador() {
        return nombre_evaluador;
    }

    public void setNombre_evaluador(String nombre_evaluador) {
        this.nombre_evaluador = nombre_evaluador;
    }

    public int getIdproyecto() {
        return idproyecto;
    }

    public void setIdproyecto(int idproyecto) {
        this.idproyecto = idproyecto;
    }
    


}
