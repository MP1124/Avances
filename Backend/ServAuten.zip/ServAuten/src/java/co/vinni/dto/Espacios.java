/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.vinni.dto;

/**
 *
 * @author Maria Paula
 */
public class Espacios {
    private String Capacidad;
    private String nombre;
   private String nivel_practica;
    private String ubicacion_lugar;
    private int idespacio;

    public Espacios() {
    }

    public Espacios(String Capacidad, String nombre, String nivel_practica, String ubicacion_lugar, int idespacio) {
        this.Capacidad = Capacidad;
        this.nombre = nombre;
        this.nivel_practica = nivel_practica;
        this.ubicacion_lugar = ubicacion_lugar;
        this.idespacio = idespacio;
    }

    public String getCapacidad() {
        return Capacidad;
    }

    public void setCapacidad(String Capacidad) {
        this.Capacidad = Capacidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNivel_practica() {
        return nivel_practica;
    }

    public void setNivel_practica(String nivel_practica) {
        this.nivel_practica = nivel_practica;
    }

    public String getUbicacion_lugar() {
        return ubicacion_lugar;
    }

    public void setUbicacion_lugar(String ubicacion_lugar) {
        this.ubicacion_lugar = ubicacion_lugar;
    }

    public int getIdespacio() {
        return idespacio;
    }

    public void setIdespacio(int idespacio) {
        this.idespacio = idespacio;
    }

    



}
