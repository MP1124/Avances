package co.vinni.servicios;

import co.vinni.dao.Conexion;
import co.vinni.dto.Proyecto;
import co.vinni.dto.Espacios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Vinni
 */
@Path("operacion")
public class Operaciones {

    List<Espacios> consultaespacio;

    @Path("version")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String version() {
        return "version 1.0";
    }

    public ArrayList<Proyecto> consultaproy() {
        PreparedStatement objPreparedStatemenet = null;
        Connection objConexion = null;
        Proyecto pr = null;
        ResultSet rs = null;

        String sqlinsert = "Select * from proyectos ";
        try {
            objConexion = Conexion.conectarse();
            objPreparedStatemenet = objConexion.prepareStatement(sqlinsert);
            rs = objPreparedStatemenet.executeQuery();
            ArrayList<Proyecto> tabla = new ArrayList<Proyecto>();
            while (rs.next()) {
                pr = new Proyecto(rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(1));
                tabla.add(pr);
                
            }

            objPreparedStatemenet.close();
            objConexion.close();
            return tabla;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

    }

   
public ArrayList<Espacios> consultaespacio() {
        PreparedStatement objPreparedStatemenet = null;
        Connection objConexion = null;
        Espacios es = null;
        ResultSet rs = null;

        String sqlinsert = "Select * from espaciofisico ";
        try {
            objConexion = Conexion.conectarse();
            objPreparedStatemenet = objConexion.prepareStatement(sqlinsert);
            rs = objPreparedStatemenet.executeQuery();
            ArrayList<Espacios> tablita = new ArrayList<Espacios>();
            while (rs.next()) {
                es = new Espacios(rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getInt(1));
                tablita.add(es);
                
            }

            objPreparedStatemenet.close();
            objConexion.close();
            return tablita;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }

    }
}


