/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.vinni.servicios;

import co.vinni.dto.Espacios;
import co.vinni.dto.Proyecto;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Maria Paula
 */
@Path("consulta")
public class servicio {

    @Path("consultaproy")
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    
    
    public List<Proyecto> tabla() {
        Operaciones op = new Operaciones();
        List<Proyecto> tabla = op.consultaproy();

        if (tabla == null) {
            tabla = new ArrayList<Proyecto>();
            return tabla;
        } else {
            return tabla;
        }
}

    @Path("consultaespacio")
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
   
      public List<Espacios> tablita() {
        Operaciones op = new Operaciones();
        List<Espacios> tablita = op.consultaespacio();

        if (tablita == null) {
            tablita = new ArrayList<Espacios>();
            return tablita;
        } else {
            return tablita;
        }
    }
}
